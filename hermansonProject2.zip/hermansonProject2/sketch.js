let reels = [0, 0, 0];
let spinning = false;
let stopTimes = [0, 0, 0];
let forcedWin = false;


let handleY = 140;         
let handleUp = 140;        
let handleDown = 200;      
let handleState = "idle";  

function setup() {
  createCanvas(500, 350);
  textAlign(CENTER, CENTER);
  textSize(48);
}

function draw() {
  background(20);

  drawMachineArt();
  drawHandle();

  
  for (let i = 0; i < 3; i++) {
    
    fill(200);
    rect(90 + i * 110, 110, 100, 120, 12);

   
    fill(255);
    rect(95 + i * 110, 115, 90, 110, 8);

    
    fill(0);
    text(reels[i], 140 + i * 110, 170);
  }

  updateHandle();

  
  if (spinning) {
    for (let i = 0; i < 3; i++) {
      if (millis() < stopTimes[i]) {
        reels[i] = floor(random(10));
      } else {
        if (forcedWin) reels[i] = 7;
      }
    }

   
    if (millis() > stopTimes[2]) {
      spinning = false;

      if (reels[0] === 7 && reels[1] === 7 && reels[2] === 7) {
        setTimeout(() => {
          alert(" JACKPOT! You win! ");
        }, 200);
      }
    }
  }
}

function keyPressed() {
  if (key === " ") startSpin();
}

function startSpin() {
  forcedWin = random() < 0.1; 

 
  handleState = "pulling";

  let now = millis();
  stopTimes[0] = now + 700;
  stopTimes[1] = now + 1100;
  stopTimes[2] = now + 1500;

  spinning = true;
}


function drawMachineArt() {
  noStroke();

  
  fill(60);
  rect(40, 40, 420, 260, 20);

  
  fill(90);
  rect(60, 80, 380, 200, 20);

  
  fill(255, 220, 60);
  rect(120, 50, 260, 40, 10);
  fill(0);
  textSize(28);
  text("Marko's Slot", 250, 70);

  
  fill(50);
  rect(120, 285, 260, 35, 10);

  
  fill(255);
  textSize(16);
  text("Press SPACE", 250, 302);

  textSize(48);
}


function drawHandle() {
  
  fill(220);
  rect(450, 110, 15, 120, 8);

 
  fill(180);
  rect(457, 120, 5, handleY - 120, 3);

  
  fill(255, 60, 60);
  ellipse(460, handleY, 28, 28);
}


function updateHandle() {
  if (handleState === "pulling") {
    handleY += 6;
    if (handleY >= handleDown) {
      handleY = handleDown;
      handleState = "returning";
    }
  } else if (handleState === "returning") {
    handleY -= 5;
    if (handleY <= handleUp) {
      handleY = handleUp;
      handleState = "idle";
    }
  }
}
